# Deployment Guide

Steps to deploy smart contract and host on IPFS.