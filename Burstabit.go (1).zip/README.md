# Burstabit.go Crash Game
A TRON-based crash game DApp.